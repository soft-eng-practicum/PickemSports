describe('true', function() {
  it('Should be true', function() {
    expect(true).toBeTruthy();
  });
});

describe('nbacontroller', function () {
  
  var scope = null;
  var nbateams = null;
  var NbaController = null;

  beforeEach(module('sportsApp.controllers.nba'));
  
  beforeEach(inject(function ($rootScope, $controller, nbateams) {
    scope = $rootScope.$new();
    NbaController = $controller('NbaController', {
      $scope: scope
    });
  }));

  it('should say test', function () {
    expect(scope.test).toBe("test");
    });
  });